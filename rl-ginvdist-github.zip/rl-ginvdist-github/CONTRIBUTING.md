# Contributing to RL-GInvDist

Спасибо за интерес к проекту! Вот руководство по внесению вклада.

## Как начать

1. **Fork репозиторий**
   ```bash
   git clone https://github.com/your-username/rl-ginvdist.git
   cd rl-ginvdist
   ```

2. **Создайте виртуальное окружение**
   ```bash
   python -m venv venv
   source venv/bin/activate  # На Windows: venv\Scripts\activate
   ```

3. **Установите зависимости**
   ```bash
   pip install -r requirements.txt
   pip install pytest black flake8  # Для разработки
   ```

## Рабочий процесс

1. **Создайте ветку для своей функции**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Делайте регулярные коммиты**
   ```bash
   git add .
   git commit -m "Add clear description of changes"
   ```

3. **Тестируйте ваш код**
   ```bash
   python -m pytest tests/
   black .  # Форматирование кода
   flake8 .  # Проверка стиля
   ```

4. **Отправьте pull request**
   - Опишите изменения четко
   - Укажите связанные issues
   - Ожидайте review

## Правила кода

### Стиль
- Используйте **PEP 8**
- Максимальная длина строки: 100 символов
- Используйте **type hints** где возможно

### Документация
- Документируйте все public функции и классы
- Используйте docstrings в формате Google

```python
def example_function(param1: int, param2: str) -> bool:
    """
    Краткое описание функции.
    
    Более подробное описание того, что делает функция,
    её параметров и возвращаемого значения.
    
    Args:
        param1: Описание первого параметра
        param2: Описание второго параметра
    
    Returns:
        Описание возвращаемого значения
    
    Raises:
        ValueError: Когда возникает эта ошибка
    """
    return True
```

### Коммиты
- Используйте осмысленные сообщения коммитов
- Начинайте с глагола: "Add", "Fix", "Update", "Remove"
- Ссылайтесь на issues: "Fix #123"

```
✅ Хорошо:
Add LSTM layer for sequence processing (#45)
Fix memory leak in feature extractor

❌ Плохо:
fixed stuff
update
asdf
```

## Репортинг проблем

### Перед созданием issue, проверьте:
- Не создана ли уже подобная issue
- Используете ли вы последнюю версию
- Проблема воспроизводится на чистой установке

### При создании issue включите:
```
**Описание проблемы**
Четкое и краткое описание.

**Шаги воспроизведения**
1. Сделайте это
2. Потом это
3. Ошибка происходит тут

**Ожидаемое поведение**
Что должно было случиться.

**Фактическое поведение**
Что произошло на самом деле.

**Окружение**
- OS: Ubuntu 22.04
- Python: 3.10
- PyTorch: 1.13.1

**Логи/Traceback**
Если есть, вставьте здесь
```

## Улучшения проекта

### Идеи для контрибьютов:

1. **Архитектура моделей**
   - RNN/LSTM поддержка
   - Attention механизмы
   - Transformer архитектура

2. **Оптимизация**
   - Параллелизм обучения
   - Distributed training
   - Model quantization

3. **Интеграция**
   - Real GInvDist integration
   - Sage CAS подключение
   - MacauleyMatrix feature extraction

4. **Документация**
   - Дополнительные примеры
   - API документация
   - Видео туториалы

5. **Тестирование**
   - Unit tests
   - Integration tests
   - Performance benchmarks

## Лицензия

Внося вклад в этот проект, вы соглашаетесь, что ваш вклад будет лицензирован под MIT License.

## Контакты

- **Научный руководитель:** Салпагаров С.И.
- **Автор:** Павленко Сергей
- **Email:** sergey.pavlenko@rudn.ru

---

**Спасибо за вклад! 🚀**
